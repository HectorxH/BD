Nombre: Héctor Larrañaga
ROL: 201873623-6

Ejecutar el archivo sansanito_pokemon.py
Instrucciones de uso estan detalladas en el mismo programa al utilizar el comando '?'.